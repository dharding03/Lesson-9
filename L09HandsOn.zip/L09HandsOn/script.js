function displayBio() {
    let bioRequest = new XMLHttpRequest();
    bioRequest.onreadystatechange = function(){
    if (this.readyState == 4 && this.status == 200){
        let bioObject = JSON.parse(this.responseText);
        document.getElementById("bio").innerHTML = bioObject.bio;
    }

}
bioRequest.open("GET" , "einstein.json" , true);
bioRequest.send();
}
function displayName (){
    let nameRequest = new XMLHttpRequest();
    nameRequest.onreadystatechange = function(){
        if (this.readyState == 4 && this.status == 200){
            let nameObject = JSON.parse(this.responseText);
            document.getElementById("name").innerHTML = nameObject.name;
        }
    }
nameRequest.open ("GET" , "einstein.json" , true);
nameRequest.send();
}
function displayBirthday (){
    let birthdayRequest = new XMLHttpRequest();
    birthdayRequest.onreadystatechange = function(){
        if (this.readyState == 4 && this.status == 200){
            let birthdayObject = JSON.parse(this.responseText);
            document.getElementById("birthday").innerHTML = birthdayObject.birthday;
        }
    }
birthdayRequest.open ("GET" , "einstein.json" , true);
birthdayRequest.send();
}
displayName();
displayBirthday();